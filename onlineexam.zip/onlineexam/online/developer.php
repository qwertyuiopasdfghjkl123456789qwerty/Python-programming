<!DOCTYPE html>

<head>
<title> DEVELOPER INFO </title>
</head>

<body>
<style type="text/css">
            body {
                width: 60%;
                background: url(image/bulb.jpg) ;
                background-position: center center;
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-size: cover;
            }
        </style>
<p>
		<div class="row">
		<div class="col-md-4">
		 <center><img src="image/sir.jpg" width=300 height=270 alt="vishrut,prem" align="center"></center>
		 </div>
		 <div class="col-md-5">
		<center><h4 style="color:yellow; font-family:'gruppo' ; font-size:24px">Prem Madhani <br/> Vishrut shah</h4>
		<h4 style="color:yellow; font-family:'gruppo' ;font-size:26px" class="title1">+91 9930726366 <br/> +91 9372066955 <br/> </h4>
		<h4 style="color:yellow; font-family:'gruppo';font-size:22px">premmadahni03@gmail.com <br/> svishrut24@gmail.com</h4>
		<h4 style="color:yellow; font-family:'gruppo';font-size:22px">Nagindas khandwala college</h4></div></div></center>
</p>
