<?php
$con= new mysqli('localhost','root','swaminiji007','exam')or die("Could not connect to mysql".mysqli_error($con));

?>
