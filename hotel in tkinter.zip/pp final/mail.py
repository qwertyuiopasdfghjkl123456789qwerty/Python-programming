import mysql.connector as mysql
dbconn = mysql.connect(user = "root",password = "swaminiji007",host = "127.0.0.1")
if (dbconn):
    print ("connection successfully")
else:
    print ("failed")

    dbconn.execute("use continental_hotel")
    dbconn.execute('insert into chk_in (name,address,number,days,room,payment) values("name1","malad",1234345676,23,"delux",343)')
    dbconn.commit()
    dbconn.close()
cur = dbconn.cursor()


